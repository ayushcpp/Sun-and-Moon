// Visual check against a running dev server (npm run dev):  npm run verify [outDir]
// 1. the story's beats (curtains, dialogue, reach, touch, eyes and poem, closing), landscape and phone
// 2. 30 fps strips across the first blink of each face, to judge it frame by frame
import { execFileSync } from 'node:child_process';
import { blinkSchedule } from '../src/blink.ts';

const out = process.argv[2] ?? 'shots';
const run = (...args) => execFileSync('node', ['scripts/shots.mjs', '--out', out, ...args], { stdio: 'inherit' });

run('--t', '0.8,3.5,9,15,21.4,22.4,26,31,38,45,50,52', '--size', '1920x1080');
run('--t', '3.5,15,21.4,31,52', '--size', '390x844', '--dpr', '2');
for (const face of ['sun', 'moon']) {
  const b = blinkSchedule[face][0];
  const times = Array.from({ length: 12 }, (_, i) => (b.at - 0.05 + i / 30).toFixed(3));
  run('--t', times.join(','), '--size', '1280x720', '--prefix', `blink-${face}_`);
}
