# /// script
# requires-python = "==3.11.*"
# dependencies = ["numpy>=1.26", "pillow>=10", "scipy>=1.11", "opencv-contrib-python-headless>=4.9"]
# ///
"""Cut the storybook images into layers.  Run: npm run assets  (uv, Python 3.11)

Inputs (project root): "Sun and Moon.jpeg", Hands.png, Faces2.png.
Outputs: public/story/*.png|jpg (layers) and src/generated/story.ts (sizes,
anchors, the moon's outline, eyelid curves). assets-preview.png shows every
cut-out and eyelid curve for checking.
"""
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "public" / "story"
PREVIEW = ROOT / "assets-preview.png"  # for checking by eye; outside public/ so it is not deployed
TS_OUT = ROOT / "src" / "generated" / "story.ts"

# Hand-measured on a pixel grid (see PLAN.md). Everything else is derived.
SUN_CENTRE, SUN_ZONE_R = (428, 235), 350
MOON_ZONE = (925, 25, 1455, 540)  # x0, y0, x1, y1
FACES = "Faces2.png"
GOLD_LUMA = 0.28
STAR_MAX_Y = 470  # big stars live above this line; below it gold bits are cloud tops
HANDS = {
    # tip: index fingertip; pivot: where the arm leaves the picture (the puppet's shoulder).
    "moon": dict(seed=(300, 330), tip=(532, 468), pivot=(0, 120)),
    "sun": dict(seed=(800, 800), tip=(562, 582), pivot=(1211, 1225)),
}
# Each eye's almond, traced on Faces2.png: the two corners, then the upper lid (the
# bottom of the drawn lid band) and the lower lid (the top of the lower lid line) at
# the middle, checked by simulating closed eyes. The iris drawing splits the sclera, so a flood
# fill cannot find the almond; three points per lid give a clean quadratic.
EYES = {
    "sunLeft": dict(corners=((245, 280), (600, 293)), upper=(420, 233), lower=(420, 308)),
    "sunRight": dict(corners=((1045, 297), (1386, 281)), upper=(1216, 223), lower=(1216, 308)),
    "moonLeft": dict(corners=((257, 757), (612, 800)), upper=(420, 692), lower=(420, 806)),
    "moonRight": dict(corners=((1090, 791), (1418, 765)), upper=(1254, 687), lower=(1254, 805)),
}


def disk(r):
    y, x = np.ogrid[-r : r + 1, -r : r + 1]
    return x * x + y * y <= r * r


def load(name):
    return np.asarray(Image.open(ROOT / name).convert("RGB")).astype(np.float32) / 255


def luma(img):
    return img @ np.array([0.2126, 0.7152, 0.0722], np.float32)


def feather(mask, sigma=1.0):
    return np.clip(ndi.gaussian_filter(mask.astype(np.float32), sigma), 0, 1)


def largest(mask):
    lab, n = ndi.label(mask)
    if n == 0:
        return mask
    sizes = ndi.sum(mask, lab, range(1, n + 1))
    return lab == (int(np.argmax(sizes)) + 1)


def save_cutout(img, alpha, name, margin=4):
    ys, xs = np.nonzero(alpha > 0.01)
    x0, y0 = max(0, xs.min() - margin), max(0, ys.min() - margin)
    x1, y1 = min(img.shape[1], xs.max() + 1 + margin), min(img.shape[0], ys.max() + 1 + margin)
    rgba = np.dstack([img[y0:y1, x0:x1], alpha[y0:y1, x0:x1]])
    Image.fromarray((rgba * 255).round().astype(np.uint8), "RGBA").save(OUT / f"{name}.png", optimize=True)
    return [int(x0), int(y0), int(x1), int(y1)]


def sky_layers(meta):
    img = load("Sun and Moon.jpeg")
    H, W, _ = img.shape
    lum = luma(img)
    gold = (lum > GOLD_LUMA) & (img[..., 0] > img[..., 2] + 0.05)
    yy, xx = np.mgrid[0:H, 0:W]

    # Clouds are the big gold masses connected to the bottom edge; the sun and moon never touch it.
    opened = ndi.binary_opening(gold, structure=np.ones((11, 11)))
    lab, _ = ndi.label(opened)
    clouds = np.isin(lab, list(set(np.unique(lab[-3:, :])) - {0}))
    padded = np.pad(ndi.binary_closing(clouds, structure=disk(9)), ((0, 4), (0, 0)), constant_values=True)
    cloud_solid = ndi.binary_fill_holes(padded)[:H]
    cloud_solid |= ndi.binary_dilation(clouds, disk(2)) & gold

    sun_zone = (xx - SUN_CENTRE[0]) ** 2 + (yy - SUN_CENTRE[1]) ** 2 < SUN_ZONE_R**2
    sun = ndi.binary_fill_holes(ndi.binary_closing(gold & sun_zone & ~cloud_solid, structure=disk(3)))
    lab, n = ndi.label(sun)
    keep = [i + 1 for i in range(n) if ndi.sum(sun, lab, i + 1) > 400]
    sun = np.isin(lab, keep)

    mx0, my0, mx1, my1 = MOON_ZONE
    moon_zone = (xx > mx0) & (xx < mx1) & (yy > my0) & (yy < my1)
    moon = largest(ndi.binary_fill_holes(ndi.binary_closing(gold & moon_zone, structure=disk(4))))

    # Big painted stars: compact gold shapes in the open sky (cloud tops also break into star-sized bits).
    open_sky = (yy < STAR_MAX_Y) & ~ndi.binary_dilation(cloud_solid, disk(12))
    rest = ndi.binary_closing(gold & ~sun_zone & ~moon_zone & open_sky, structure=disk(2))
    lab, n = ndi.label(rest)
    stars = []
    for i in range(1, n + 1):
        comp = lab == i
        area = int(comp.sum())
        if 250 < area < 8000:
            stars.append(ndi.binary_fill_holes(comp))

    # Sky plate: sun, moon and big stars removed and painted over from the surrounding sky.
    # The clouds stay in it; an identical cloud cut-out drawn on top lets the sun sink behind
    # them, and since both move together nothing ghosts.
    bgr = cv2.cvtColor((img * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    bodies = sun | moon
    for s in stars:
        bodies |= s
    hole = ndi.binary_dilation(bodies, disk(7))
    plate = np.zeros_like(bgr)
    cv2.xphoto.inpaint(bgr, ((~hole) * 255).astype(np.uint8), plate, cv2.xphoto.INPAINT_SHIFTMAP)
    # Shift-map can copy stray gold fragments into the old sun's place: paint any
    # non-star-like bit over again, with shift-map too (smooth fills read as smudges).
    pf = cv2.cvtColor(plate, cv2.COLOR_BGR2RGB).astype(np.float32) / 255
    stray = (luma(pf) > 0.18) & (pf[..., 0] > pf[..., 2] + 0.08) & ndi.binary_dilation(hole, disk(4))
    lab, n = ndi.label(stray)
    fragments = np.zeros_like(stray)
    for i in range(1, n + 1):
        comp = lab == i
        if comp.sum() > 6:
            fragments |= comp
    if fragments.any():
        again = np.zeros_like(plate)
        cv2.xphoto.inpaint(plate, ((~ndi.binary_dilation(fragments, disk(4))) * 255).astype(np.uint8), again, cv2.xphoto.INPAINT_SHIFTMAP)
        plate = again
    plate_rgb = cv2.cvtColor(plate, cv2.COLOR_BGR2RGB)
    Image.fromarray(plate_rgb).save(OUT / "sky.jpg", quality=93)

    # Painted star dots left in the plate: small bright specks, for the twinkle.
    pl = luma(plate_rgb.astype(np.float32) / 255)
    specks = (pl > 0.42) & ~ndi.binary_dilation(cloud_solid, disk(3))
    lab, n = ndi.label(specks)
    sizes = ndi.sum(specks, lab, range(1, n + 1))
    dots = np.isin(lab, [i + 1 for i in range(n) if sizes[i] <= 60])
    twinkle = feather(ndi.binary_dilation(dots, disk(1)), 0.8)
    Image.fromarray((twinkle * 255).astype(np.uint8), "L").save(OUT / "sky_twinkle.png", optimize=True)

    meta["sky"] = {"size": [W, H]}
    meta["sun"] = {"box": save_cutout(img, feather(ndi.binary_dilation(sun, disk(1)), 0.8), "sun"), "centre": list(SUN_CENTRE)}
    moon_box = save_cutout(img, feather(ndi.binary_dilation(moon, disk(1)), 0.8), "moon")
    ys, xs = np.nonzero(moon)
    # The crescent's outline (convex hull, ~20 points within 3 px) keeps it on screen.
    hull = cv2.approxPolyDP(cv2.convexHull(np.column_stack([xs, ys]).astype(np.int32)), 3, True)[:, 0]
    meta["moon"] = {
        "box": moon_box,
        "centre": [round(float(xs.mean()), 1), round(float(ys.mean()), 1)],
        "hull": [[int(x), int(y)] for x, y in hull],
    }
    meta["stars"] = []
    for k, s in enumerate(sorted(stars, key=lambda m: np.nonzero(m)[1].mean())):
        ys, xs = np.nonzero(s)
        box = save_cutout(img, feather(ndi.binary_dilation(s, disk(1)), 0.7), f"star{k}")
        meta["stars"].append({"box": box, "centre": [round(float(xs.mean()), 1), round(float(ys.mean()), 1)]})
    cloud_alpha = feather(cloud_solid, 1.0)
    split = W // 2
    left = cloud_alpha.copy()
    left[:, split:] = 0
    right = cloud_alpha.copy()
    right[:, :split] = 0
    meta["clouds"] = {"left": {"box": save_cutout(img, left, "clouds_left")}, "right": {"box": save_cutout(img, right, "clouds_right")}}
    return {"sun": sun, "moon": moon, "stars": stars, "clouds": cloud_solid, "plate": plate_rgb}


def hand_layers(meta):
    img = load("Hands.png")
    lum = luma(img)
    ink = ndi.binary_closing(lum > 0.06, structure=disk(3))
    lab, _ = ndi.label(ink)
    meta["hands"] = {"size": [img.shape[1], img.shape[0]]}
    for name, h in HANDS.items():
        part = lab == lab[h["seed"][1], h["seed"][0]]
        part = ndi.binary_fill_holes(ndi.binary_closing(part, structure=disk(6)))
        box = save_cutout(img, feather(part, 0.9), f"hand_{name}")
        meta["hands"][name] = {"box": box, "tip": list(h["tip"]), "pivot": list(h["pivot"])}


def eye_curves(meta):
    """Upper and lower lid of each eye as quadratics through the measured points."""
    img = load(FACES)
    H, W, _ = img.shape
    meta["faces"] = {"size": [W, H], "eyes": {}}
    found = {}
    for name, e in EYES.items():
        (ax, ay), (bx, by) = e["corners"]
        up = np.polyfit([ax, e["upper"][0], bx], [ay, e["upper"][1], by], 2)
        dn = np.polyfit([ax, e["lower"][0], bx], [ay, e["lower"][1], by], 2)
        x0, x1 = min(ax, bx), max(ax, bx)
        meta["faces"]["eyes"][name] = {
            "x": [x0, x1],
            "upper": [round(float(c), 8) for c in up],
            "lower": [round(float(c), 8) for c in dn],
        }
        found[name] = (None, up, dn, x0, x1)
    return img, found


def preview(sky, faces_img, eyes):
    W, H = sky["plate"].shape[1], sky["plate"].shape[0]
    p = Image.fromarray(sky["plate"]).convert("RGB")
    d = ImageDraw.Draw(p)
    for m, col in [(sky["sun"], (255, 90, 160)), (sky["moon"], (90, 150, 255)), (sky["clouds"], (255, 230, 120))] + [(s, (255, 255, 255)) for s in sky["stars"]]:
        edge = m ^ ndi.binary_erosion(m, disk(2))
        arr = np.asarray(p).copy()
        arr[edge] = col
        p = Image.fromarray(arr)
    f = Image.fromarray((faces_img * 255).astype(np.uint8))
    d = ImageDraw.Draw(f)
    for name, (_, up, dn, x0, x1) in eyes.items():
        for coeffs, col in [(up, (255, 60, 60)), (dn, (60, 255, 60))]:
            pts = [(x, float(np.polyval(coeffs, x))) for x in range(x0, x1 + 1, 3)]
            d.line(pts, fill=col, width=2)
    canvas = Image.new("RGB", (W + f.size[0], max(H, f.size[1])))
    canvas.paste(p, (0, 0))
    canvas.paste(f, (W, 0))
    canvas.save(PREVIEW, optimize=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.iterdir():  # generated folder: start clean so no stale layer survives
        old.unlink()
    meta = {}
    sky = sky_layers(meta)
    hand_layers(meta)
    faces_img, eyes = eye_curves(meta)
    Image.open(ROOT / FACES).convert("RGB").save(OUT / "faces.jpg", quality=92)
    preview(sky, faces_img, eyes)
    TS_OUT.parent.mkdir(parents=True, exist_ok=True)
    TS_OUT.write_text(
        "// Generated by scripts/prepare_assets.py (npm run assets). Do not edit by hand.\n"
        "// Pixel coordinates in each source image, y down. Boxes are [x0, y0, x1, y1] of the\n"
        "// cut-out PNGs; eyelid curves are quadratics y = a x^2 + b x + c over x in [x0, x1].\n"
        f"export const STORY = {json.dumps(meta, indent=2)} as const;\n"
    )
    print("stars:", len(meta["stars"]), "| wrote", OUT.relative_to(ROOT), "and", TS_OUT.relative_to(ROOT))


if __name__ == "__main__":
    main()
