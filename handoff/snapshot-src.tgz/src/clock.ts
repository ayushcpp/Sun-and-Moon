import { clampTime } from './timeline.ts';

/**
 * Scene time derived from the wall clock: t = anchor + (now - anchorWall) * rate.
 * Nothing is accumulated per frame, so time cannot drift.
 */
export class Clock {
  private anchorT: number;
  private anchorWall = 0;
  private running = false;
  private rate: number;

  constructor(startT: number, rate = 1) {
    this.anchorT = clampTime(startT);
    this.rate = rate;
  }

  get paused(): boolean {
    return !this.running;
  }

  now(wallMs: number): number {
    return this.running ? clampTime(this.anchorT + ((wallMs - this.anchorWall) / 1000) * this.rate) : this.anchorT;
  }

  play(wallMs: number): void {
    if (this.running) return;
    this.anchorWall = wallMs;
    this.running = true;
  }

  pause(wallMs: number): void {
    if (!this.running) return;
    this.anchorT = this.now(wallMs);
    this.running = false;
  }

  toggle(wallMs: number): void {
    if (this.running) this.pause(wallMs);
    else this.play(wallMs);
  }

  seek(t: number, wallMs: number): void {
    this.anchorT = clampTime(t);
    this.anchorWall = wallMs;
  }

  /** Changes speed from now on without a jump (prefers-reduced-motion toggled mid-film). */
  setRate(rate: number, wallMs: number): void {
    this.anchorT = this.now(wallMs);
    this.anchorWall = wallMs;
    this.rate = rate;
  }

  scrub(deltaSeconds: number, wallMs: number): void {
    this.seek(this.now(wallMs) + deltaSeconds, wallMs);
  }
}
