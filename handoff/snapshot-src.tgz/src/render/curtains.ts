// The storybook theatre: a painted kathputli stage whose block-printed drapes
// part to open the story and close at its end.
// Contract: update() reads only state.curtain (open 0 closed .. 1 drawn aside
// and out of view, light 0 dark .. 1 lit), state.t and the view; the mesh is a
// full-screen clip-space quad drawn over everything (renderOrder 20).
// Everything that is easier to paint than to compute (the block print, the
// zari border, the Madhubani frame, the toran, the title board) is painted once
// at startup on 2D canvases with seeded randomness; one fragment shader folds
// the cloth and composes the stage, front to back.
import * as THREE from 'three';
import { CURTAINS, TIMELINE } from '../config.ts';
import { clamp, easeOutCubic, lerp, progress, ramp } from '../lib/math.ts';
import { seededRandom } from '../lib/random.ts';
import type { StoryState, View } from '../types.ts';
import { FULLSCREEN_VERTEX, GLSL_COMMON } from './shaders/common.ts';

const C = CURTAINS;
const P = C.paint;
const TAU = Math.PI * 2;
const TITLE_FONT = '400 150px "IM Fell English"';

type G = CanvasRenderingContext2D;
type Rand = () => number;

// #region painting

function surface(w: number, h: number): [HTMLCanvasElement, G] {
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const g = canvas.getContext('2d')!;
  g.lineCap = 'round';
  g.lineJoin = 'round';
  return [canvas, g];
}

/** Draws f translated to (x, y) and to its copies one tile away, so a repeating tile has no seams. */
function wrapped(g: G, w: number, h: number, x: number, y: number, f: () => void): void {
  for (const dx of [-w, 0, w])
    for (const dy of h ? [-h, 0, h] : [0]) {
      g.save();
      g.translate(x + dx, y + dy);
      f();
      g.restore();
    }
}

function outline(g: G, color: string, width: number): void {
  g.strokeStyle = color;
  g.lineWidth = width;
  g.stroke();
}

function fill(g: G, color: string | CanvasGradient): void {
  g.fillStyle = color;
  g.fill();
}

/** A paisley (buta): bulb of radius ~0.5 at the origin, its tip curling over to the right. */
function butaPath(g: G): void {
  g.beginPath();
  g.moveTo(0, 0.5);
  g.bezierCurveTo(-0.6, 0.5, -0.64, -0.25, -0.32, -0.62);
  g.bezierCurveTo(-0.06, -0.94, 0.4, -1.02, 0.6, -0.76);
  g.bezierCurveTo(0.32, -0.74, 0.18, -0.52, 0.4, -0.26);
  g.bezierCurveTo(0.62, 0.02, 0.44, 0.5, 0, 0.5);
  g.closePath();
}

/** A crescent of radius r whose hollow faces +x; `cut` is how far the inner circle is shifted (of r). */
function crescentPath(g: G, r: number, cut: number): void {
  const dx = r * cut;
  const rr = r * 0.86;
  const xi = (r * r - rr * rr + dx * dx) / (2 * dx);
  const yi = Math.sqrt(Math.max(r * r - xi * xi, 0));
  const ao = Math.atan2(yi, xi);
  g.beginPath();
  g.arc(0, 0, r, ao, TAU - ao, false);
  g.arc(dx, 0, rr, Math.atan2(-yi, xi - dx), Math.atan2(yi, xi - dx), true);
  g.closePath();
}

/** A ruffled marigold (genda) flower. */
function marigold(g: G, x: number, y: number, r: number, rand: Rand, yellow: boolean): void {
  const tones = yellow ? ['#b8730c', '#eba816', '#fbcf4c'] : ['#a8420a', '#e5730f', '#f59a2a'];
  for (let layer = 0; layer < 3; layer++) {
    const rl = r * (1 - layer * 0.27);
    const lobes = 13 - layer * 3;
    const ph = rand() * TAU;
    g.beginPath();
    for (let i = 0; i <= 72; i++) {
      const a = (i / 72) * TAU;
      const k = 0.8 + 0.2 * Math.abs(Math.sin((a * lobes) / 2 + ph));
      g.lineTo(x + Math.cos(a) * rl * k, y + Math.sin(a) * rl * k);
    }
    fill(g, tones[layer]);
  }
  g.lineWidth = Math.max(1, r * 0.07);
  g.strokeStyle = yellow ? 'rgba(150, 80, 0, 0.45)' : 'rgba(110, 30, 0, 0.45)';
  for (let i = 0; i < 9; i++) {
    const a = rand() * TAU;
    g.beginPath();
    g.moveTo(x + Math.cos(a) * r * 0.25, y + Math.sin(a) * r * 0.25);
    g.lineTo(x + Math.cos(a) * r * 0.78, y + Math.sin(a) * r * 0.78);
    g.stroke();
  }
}

/** A mango leaf hanging from (0, 0), pointing down. */
function mangoLeaf(g: G, len: number, wid: number): void {
  g.beginPath();
  g.moveTo(0, 0);
  g.bezierCurveTo(wid, len * 0.22, wid * 0.95, len * 0.68, 0, len);
  g.bezierCurveTo(-wid * 0.95, len * 0.68, -wid, len * 0.22, 0, 0);
  const grad = g.createLinearGradient(-wid, 0, wid, 0);
  grad.addColorStop(0, '#24561d');
  grad.addColorStop(0.5, P.leaf);
  grad.addColorStop(1, '#2d6322');
  fill(g, grad);
  outline(g, '#173a14', 1.5);
  g.beginPath();
  g.moveTo(0, len * 0.04);
  g.lineTo(0, len * 0.9);
  outline(g, P.leafLight, 1.6);
}

/** A small brass bell (ghanti) hanging from (0, 0). */
function bell(g: G, w: number, h: number): void {
  g.beginPath();
  g.moveTo(0, 0);
  g.lineTo(0, h * 0.18);
  outline(g, P.goldDeep, w * 0.08);
  g.beginPath();
  g.moveTo(-w * 0.14, h * 0.2);
  g.bezierCurveTo(-w * 0.34, h * 0.24, -w * 0.32, h * 0.62, -w * 0.5, h * 0.84);
  g.lineTo(w * 0.5, h * 0.84);
  g.bezierCurveTo(w * 0.32, h * 0.62, w * 0.34, h * 0.24, w * 0.14, h * 0.2);
  g.closePath();
  const grad = g.createLinearGradient(-w * 0.5, 0, w * 0.5, 0);
  grad.addColorStop(0, '#7a4f16');
  grad.addColorStop(0.35, P.goldLight);
  grad.addColorStop(0.6, P.brass);
  grad.addColorStop(1, '#6b4412');
  fill(g, grad);
  outline(g, '#4a2c0a', 1.4);
  g.beginPath();
  g.ellipse(0, h * 0.84, w * 0.5, h * 0.06, 0, 0, TAU);
  fill(g, '#8a5a17');
  g.beginPath();
  g.arc(0, h * 0.95, w * 0.1, 0, TAU);
  fill(g, '#5a3a10');
}

/** A Madhubani sun: a ring of alternating rays round a disc with a little face. */
function madhuSun(g: G, r: number): void {
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * TAU;
    g.beginPath();
    g.moveTo(Math.cos(a - 0.15) * r * 1.04, Math.sin(a - 0.15) * r * 1.04);
    g.lineTo(Math.cos(a) * r * 1.55, Math.sin(a) * r * 1.55);
    g.lineTo(Math.cos(a + 0.15) * r * 1.04, Math.sin(a + 0.15) * r * 1.04);
    g.closePath();
    fill(g, i % 2 ? P.madhuRed : P.madhuOchre);
    outline(g, P.ink, r * 0.06);
  }
  g.beginPath();
  g.arc(0, 0, r, 0, TAU);
  fill(g, P.madhuOchre);
  outline(g, P.ink, r * 0.09);
  g.beginPath();
  g.arc(0, 0, r * 0.8, 0, TAU);
  outline(g, P.madhuRed, r * 0.08);
  // eyes, nose and smile
  for (const s of [-1, 1]) {
    g.beginPath();
    g.ellipse(s * r * 0.32, -r * 0.12, r * 0.17, r * 0.08, 0, 0, TAU);
    fill(g, P.cream);
    outline(g, P.ink, r * 0.05);
    g.beginPath();
    g.arc(s * r * 0.32, -r * 0.12, r * 0.05, 0, TAU);
    fill(g, P.ink);
  }
  g.beginPath();
  g.moveTo(0, -r * 0.05);
  g.quadraticCurveTo(r * 0.08, r * 0.15, -r * 0.03, r * 0.2);
  outline(g, P.ink, r * 0.05);
  g.beginPath();
  g.arc(0, r * 0.28, r * 0.22, 0.25 * Math.PI, 0.75 * Math.PI);
  outline(g, P.madhuRed, r * 0.08);
}

/** A Madhubani fish facing +x, centred, `len` long. */
function madhuFish(g: G, len: number): void {
  const h = len * 0.34;
  g.beginPath();
  g.moveTo(-len * 0.3, 0);
  g.lineTo(-len * 0.5, -h * 0.55);
  g.quadraticCurveTo(-len * 0.42, 0, -len * 0.5, h * 0.55);
  g.closePath();
  fill(g, P.madhuRed);
  outline(g, P.ink, len * 0.02);
  g.beginPath();
  g.moveTo(len * 0.5, 0);
  g.bezierCurveTo(len * 0.3, -h * 0.85, -len * 0.14, -h * 0.75, -len * 0.32, 0);
  g.bezierCurveTo(-len * 0.14, h * 0.75, len * 0.3, h * 0.85, len * 0.5, 0);
  g.closePath();
  fill(g, P.madhuOchre);
  outline(g, P.ink, len * 0.025);
  g.save();
  g.clip();
  // scales: rows of small arcs
  g.strokeStyle = P.ink;
  g.lineWidth = len * 0.012;
  for (let x = -len * 0.24; x < len * 0.22; x += len * 0.07)
    for (let y = -h * 0.6; y < h * 0.7; y += h * 0.32) {
      g.beginPath();
      g.arc(x, y + ((x / (len * 0.07)) % 2 ? h * 0.16 : 0), len * 0.035, -0.5 * Math.PI, 0.5 * Math.PI);
      g.stroke();
    }
  g.restore();
  // gill, eye, fin
  g.beginPath();
  g.arc(len * 0.36, 0, h * 0.42, 0.62 * Math.PI, 1.38 * Math.PI);
  outline(g, P.ink, len * 0.02);
  g.beginPath();
  g.arc(len * 0.36, -h * 0.12, h * 0.12, 0, TAU);
  fill(g, P.cream);
  outline(g, P.ink, len * 0.015);
  g.beginPath();
  g.arc(len * 0.37, -h * 0.12, h * 0.05, 0, TAU);
  fill(g, P.ink);
  g.beginPath();
  g.moveTo(len * 0.05, -h * 0.42);
  g.quadraticCurveTo(-len * 0.02, -h * 0.85, -len * 0.12, -h * 0.5);
  fill(g, P.madhuRed);
  outline(g, P.ink, len * 0.015);
}

/** A Madhubani lotus: five hatched petals fanning up from a seed pod. */
function madhuLotus(g: G, r: number): void {
  for (const a of [-1.05, 1.05, -0.52, 0.52, 0]) {
    g.save();
    g.translate(0, r * 0.35);
    g.rotate(a);
    g.beginPath();
    g.moveTo(0, 0);
    g.bezierCurveTo(r * 0.3, -r * 0.25, r * 0.22, -r * 0.75, 0, -r * 1.02);
    g.bezierCurveTo(-r * 0.22, -r * 0.75, -r * 0.3, -r * 0.25, 0, 0);
    fill(g, a === 0 ? P.madhuRed : Math.abs(a) > 1 ? P.madhuRed : P.madhuOchre);
    outline(g, P.ink, r * 0.05);
    g.beginPath();
    g.moveTo(0, -r * 0.12);
    g.lineTo(0, -r * 0.82);
    for (const s of [-1, 1]) {
      g.moveTo(s * r * 0.08, -r * 0.16);
      g.quadraticCurveTo(s * r * 0.13, -r * 0.5, s * r * 0.04, -r * 0.74);
    }
    outline(g, P.ink, r * 0.025);
    g.restore();
  }
  g.beginPath();
  g.ellipse(0, r * 0.38, r * 0.36, r * 0.2, 0, 0, TAU);
  fill(g, P.madhuOchre);
  outline(g, P.ink, r * 0.05);
  for (let i = -2; i <= 2; i++) {
    g.beginPath();
    g.arc(i * r * 0.12, r * 0.36, r * 0.035, 0, TAU);
    fill(g, P.ink);
  }
}

/** The block-printed field: paisleys, flowers round mirrors, tiny suns and moons, vines. One square repeat. */
function paintPrint(rand: Rand): HTMLCanvasElement {
  const S = 512;
  const [canvas, g] = surface(S, S);
  const at = (x: number, y: number, f: () => void) => wrapped(g, S, S, x, y, f);
  const mirror = (C.drape.mirror / C.drape.print) * S;

  // Paisleys, each on a leafy sprig: the fill block, then the outline block a
  // hair out of register, then a halo of dots.
  const buta = (x: number, y: number, rot: number, flip: boolean) =>
    at(x, y, () => {
      g.rotate(rot);
      g.scale(flip ? -1 : 1, 1);
      g.beginPath();
      g.moveTo(-2, 34);
      g.bezierCurveTo(-8, 66, 34, 82, 56, 60);
      g.arc(47, 55, 10, 0.5, -2.2, true);
      outline(g, P.leaf, 4.5);
      for (const [lx, ly, a] of [[4, 62, 2.4], [30, 74, 0.5], [-10, 48, 3.6]]) {
        g.save();
        g.translate(lx, ly);
        g.rotate(a);
        g.beginPath();
        g.ellipse(11, 0, 12, 5, 0, 0, TAU);
        fill(g, P.leaf);
        g.beginPath();
        g.moveTo(2, 0);
        g.lineTo(19, 0);
        outline(g, P.leafLight, 1.5);
        g.restore();
      }
      g.scale(76, 76);
      butaPath(g);
      fill(g, P.turmeric);
      g.save();
      g.translate(0.02, 0.07);
      g.scale(0.62, 0.62);
      butaPath(g);
      fill(g, P.maroon);
      g.translate(0.02, 0.1);
      g.scale(0.5, 0.5);
      butaPath(g);
      fill(g, P.cream);
      g.restore();
      g.translate(-0.025, -0.02);
      butaPath(g);
      outline(g, P.ink, 0.06);
      g.save();
      g.translate(0, -0.03);
      g.scale(1.2, 1.14);
      butaPath(g);
      g.setLineDash([0.001, 0.12]);
      outline(g, P.cream, 0.075);
      g.restore();
    });
  buta(128, 160, -0.32, false);
  buta(384, 416, 0.32, true);

  // Eight-petal flowers, each round a mirror (the shader lays the glass).
  const flower = (x: number, y: number) =>
    at(x, y, () => {
      for (let i = 0; i < 8; i++) {
        g.save();
        g.rotate((i / 8) * TAU + 0.2);
        g.beginPath();
        g.ellipse(0, -mirror * 1.75, mirror * 0.52, mirror * 0.9, 0, 0, TAU);
        fill(g, P.cream);
        outline(g, P.ink, 3.5);
        g.beginPath();
        g.moveTo(0, -mirror * 1.2);
        g.lineTo(0, -mirror * 2.3);
        outline(g, P.saffron, 2.5);
        g.restore();
      }
      g.beginPath();
      g.arc(0, 0, mirror * 1.2, 0, TAU);
      outline(g, P.gold, mirror * 0.42);
      g.strokeStyle = P.goldDeep;
      g.lineWidth = 2;
      for (let i = 0; i < 22; i++) {
        const a = (i / 22) * TAU;
        g.beginPath();
        g.moveTo(Math.cos(a) * mirror * 1.0, Math.sin(a) * mirror * 1.0);
        g.lineTo(Math.cos(a) * mirror * 1.4, Math.sin(a) * mirror * 1.4);
        g.stroke();
      }
    });
  flower(384, 154);
  flower(128, 410);

  // Rows of tiny suns and crescent moons between them, for our story.
  const sun = (x: number, y: number) =>
    at(x, y, () => {
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * TAU;
        g.beginPath();
        g.moveTo(Math.cos(a - 0.16) * 17, Math.sin(a - 0.16) * 17);
        g.lineTo(Math.cos(a) * 33, Math.sin(a) * 33);
        g.lineTo(Math.cos(a + 0.16) * 17, Math.sin(a + 0.16) * 17);
        g.closePath();
        fill(g, i % 2 ? P.saffron : P.turmeric);
        outline(g, P.ink, 2.2);
      }
      g.beginPath();
      g.arc(0, 0, 16, 0, TAU);
      fill(g, P.rose);
      outline(g, P.ink, 3);
      g.beginPath();
      g.arc(0, 0, 6, 0, TAU);
      fill(g, P.turmeric);
    });
  const moon = (x: number, y: number) =>
    at(x, y, () => {
      g.rotate(-0.6);
      crescentPath(g, 27, 0.5);
      fill(g, P.blue);
      outline(g, P.ink, 3);
      g.beginPath();
      g.arc(26, -20, 3.5, 0, TAU);
      g.arc(30, 14, 2.5, 0, TAU);
      fill(g, P.cream);
    });
  sun(256, 282);
  sun(0, 26);
  moon(0, 282);
  moon(256, 26);

  // Dana: little clusters of three dots in the gaps.
  for (const [x, y] of [[192, 282], [64, 26], [320, 26], [448, 282], [256, 154], [0, 410], [256, 410], [0, 154]])
    at(x, y, () => {
      for (let i = 0; i < 3; i++) {
        const a = (i / 3) * TAU + rand() * 0.4;
        g.beginPath();
        g.arc(Math.cos(a) * 7, Math.sin(a) * 7, 4, 0, TAU);
        fill(g, P.cream);
      }
    });
  return canvas;
}

/**
 * The zari border, across x (0 = the cloth's edge) and along y (one repeat):
 * a binding, a broad woven gold band with lozenges round mirrors, a marigold
 * band of little triangles, and a picot edge into the field.
 */
function paintZari(): HTMLCanvasElement {
  const W = 256;
  const H = 512;
  const [canvas, g] = surface(W, H);
  const band = (x0: number, x1: number, color: string) => {
    g.fillStyle = color;
    g.fillRect(x0, 0, x1 - x0, H);
  };
  const mirror = ((C.drape.mirror * 0.95) / C.drape.border) * W;
  band(0, 12, '#3b070b');
  band(12, 20, P.goldLight);
  band(20, 26, P.maroon);
  band(26, 146, P.gold);
  g.save();
  g.beginPath();
  g.rect(26, 0, 120, H);
  g.clip();
  // the twill of the woven gold
  for (let y = -160; y < H + 40; y += 4) {
    g.beginPath();
    g.moveTo(26, y);
    g.lineTo(146, y + 70);
    outline(g, (y / 4) % 2 ? 'rgba(255, 236, 170, 0.22)' : 'rgba(110, 66, 10, 0.22)', 1.6);
  }
  for (const cy of [128, 384]) {
    for (const [k, color, w] of [[1, P.goldDeep, 5], [0.8, P.goldLight, 2.5]] as const) {
      g.beginPath();
      g.moveTo(86, cy - 118 * k);
      g.lineTo(86 + 56 * k, cy);
      g.lineTo(86, cy + 118 * k);
      g.lineTo(86 - 56 * k, cy);
      g.closePath();
      outline(g, color, w);
    }
    g.beginPath();
    g.arc(86, cy, mirror * 1.25, 0, TAU);
    outline(g, P.maroon, mirror * 0.4);
    g.beginPath();
    g.arc(86, cy, mirror * 1.5, 0, TAU);
    g.setLineDash([2, 7]);
    outline(g, P.goldLight, 4);
    g.setLineDash([]);
  }
  // small four-petal flowers where the lozenges meet
  for (const cy of [0, 256, 512]) {
    for (let i = 0; i < 4; i++) {
      g.save();
      g.translate(86, cy);
      g.rotate((i / 4) * TAU);
      g.beginPath();
      g.ellipse(0, -13, 7, 12, 0, 0, TAU);
      fill(g, i % 2 ? P.leaf : P.maroon);
      g.restore();
    }
    g.beginPath();
    g.arc(86, cy, 5, 0, TAU);
    fill(g, P.goldLight);
  }
  g.restore();
  band(146, 152, P.maroon);
  band(152, 158, P.goldLight);
  band(158, 222, P.marigold);
  const grad = g.createLinearGradient(158, 0, 222, 0);
  grad.addColorStop(0, 'rgba(160, 50, 0, 0.35)');
  grad.addColorStop(0.5, 'rgba(255, 200, 80, 0.15)');
  grad.addColorStop(1, 'rgba(160, 50, 0, 0.35)');
  g.fillStyle = grad;
  g.fillRect(158, 0, 64, H);
  for (let y = 0; y < H; y += 32) {
    g.beginPath();
    g.moveTo(218, y + 2);
    g.lineTo(170, y + 16);
    g.lineTo(218, y + 30);
    g.closePath();
    fill(g, P.gold);
    outline(g, P.goldDeep, 2);
    g.beginPath();
    g.arc(178, y, 4.5, 0, TAU);
    fill(g, P.leaf);
  }
  band(222, 228, P.goldLight);
  band(228, 236, P.maroon);
  for (let y = 0; y < H; y += 16) {
    g.beginPath();
    g.arc(236, y + 8, 8, -0.5 * Math.PI, 0.5 * Math.PI);
    fill(g, P.gold);
  }
  return canvas;
}

/** A painted Madhubani border band: along x (one repeat), across y (0 = the frame's outer edge). */
function paintFrame(rand: Rand): HTMLCanvasElement {
  const W = 2048;
  const H = 256;
  const [canvas, g] = surface(W, H);
  g.fillStyle = P.madhuGround;
  g.fillRect(0, 0, W, H);
  // a hand-laid wash on the plaster
  for (let i = 0; i < 90; i++) {
    const x = rand() * W;
    const y = rand() * H;
    const r = 20 + rand() * 70;
    wrapped(g, W, 0, x, y, () => {
      const grad = g.createRadialGradient(0, 0, 0, 0, 0, r);
      grad.addColorStop(0, rand() < 0.5 ? 'rgba(190, 120, 40, 0.08)' : 'rgba(255, 245, 220, 0.08)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      g.fillStyle = grad;
      g.fillRect(-r, -r, 2 * r, 2 * r);
    });
  }
  const line = (y: number, w: number) => {
    g.fillStyle = P.ink;
    g.fillRect(0, y - w / 2, W, w);
  };
  const triangles = (y0: number, y1: number, colors: string[]) => {
    const n = 64;
    const step = W / n;
    for (let i = 0; i < n; i++) {
      g.beginPath();
      g.moveTo(i * step, y0);
      g.lineTo((i + 0.5) * step, y1);
      g.lineTo((i + 1) * step, y0);
      g.closePath();
      fill(g, colors[i % colors.length]);
      outline(g, P.ink, 2.5);
    }
  };
  g.fillStyle = P.ink;
  g.fillRect(0, 0, W, 9);
  line(16, 4);
  triangles(20, 54, [P.madhuRed]);
  line(58, 4);
  line(66, 2);
  line(190, 2);
  line(198, 4);
  triangles(236, 202, [P.madhuOchre, P.madhuRed]);
  line(240, 4);
  g.fillStyle = P.ink;
  g.fillRect(0, 246, W, 10);

  const cell = W / 6;
  for (let i = 0; i < 6; i++) {
    const x0 = i * cell;
    // dividers: a red ladder between two ink lines
    g.fillStyle = P.madhuRed;
    g.fillRect(x0 - 6, 68, 12, 120);
    g.fillStyle = P.ink;
    g.fillRect(x0 - 8, 68, 3, 120);
    g.fillRect(x0 + 5, 68, 3, 120);
    for (let y = 76; y < 188; y += 12) g.fillRect(x0 - 6, y, 12, 2);
    // hatched leaves in the cell's corners (kachni line-work)
    for (const [sx, sy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
      g.save();
      g.translate(x0 + cell / 2 + sx * cell * 0.36, 128 + sy * 34);
      g.rotate(sx * sy * 0.6);
      g.beginPath();
      g.ellipse(0, 0, 26, 10, 0, 0, TAU);
      fill(g, P.leaf);
      outline(g, P.ink, 2);
      g.beginPath();
      g.moveTo(-24, 0);
      g.lineTo(24, 0);
      for (let k = -18; k <= 18; k += 6) {
        g.moveTo(k, 0);
        g.lineTo(k + 5, -8);
        g.moveTo(k, 0);
        g.lineTo(k + 5, 8);
      }
      outline(g, P.ink, 1.2);
      g.restore();
    }
    g.save();
    g.translate(x0 + cell / 2, 128);
    switch (i) {
      case 0:
        madhuSun(g, 34);
        break;
      case 3:
        g.rotate(-0.35);
        crescentPath(g, 50, 0.48);
        fill(g, P.cream);
        outline(g, P.ink, 4);
        g.beginPath();
        g.arc(-28, -8, 5, 0, TAU);
        fill(g, P.ink);
        crescentPath(g, 40, 0.75);
        outline(g, P.blue, 3);
        break;
      case 1:
      case 4:
        for (const s of [-1, 1]) {
          g.save();
          g.translate(s * 62, s * 10);
          g.scale(-s, 1);
          madhuFish(g, 112);
          g.restore();
        }
        break;
      default:
        madhuLotus(g, 56);
    }
    g.restore();
  }
  return canvas;
}

/** The square block where a pillar meets the top board or the apron: a lotus rosette. */
function paintCorner(): HTMLCanvasElement {
  const S = 256;
  const [canvas, g] = surface(S, S);
  g.fillStyle = P.ink;
  g.fillRect(0, 0, S, S);
  g.fillStyle = P.madhuGround;
  g.fillRect(14, 14, S - 28, S - 28);
  g.strokeStyle = P.ink;
  g.lineWidth = 4;
  g.strokeRect(26, 26, S - 52, S - 52);
  for (const [x, y] of [[26, 26], [S - 26, 26], [26, S - 26], [S - 26, S - 26]]) {
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + (x < S / 2 ? 34 : -34), y);
    g.lineTo(x, y + (y < S / 2 ? 34 : -34));
    g.closePath();
    fill(g, P.madhuRed);
    outline(g, P.ink, 2.5);
  }
  g.translate(S / 2, S / 2);
  g.beginPath();
  g.arc(0, 0, 86, 0, TAU);
  fill(g, P.madhuRed);
  outline(g, P.ink, 4);
  for (let i = 0; i < 8; i++) {
    g.save();
    g.rotate((i / 8) * TAU);
    g.beginPath();
    g.moveTo(0, -14);
    g.bezierCurveTo(26, -32, 18, -66, 0, -80);
    g.bezierCurveTo(-18, -66, -26, -32, 0, -14);
    fill(g, i % 2 ? P.madhuOchre : P.cream);
    outline(g, P.ink, 3);
    g.restore();
  }
  g.beginPath();
  g.arc(0, 0, 18, 0, TAU);
  fill(g, P.madhuOchre);
  outline(g, P.ink, 3);
  return canvas;
}

/** The stage's front edge: a gilt moulding, a row of gold kangura, and calm dark lacquered wood. */
function paintApron(rand: Rand): HTMLCanvasElement {
  const W = 1024;
  const H = 256;
  const [canvas, g] = surface(W, H);
  g.fillStyle = P.wood;
  g.fillRect(0, 0, W, H);
  for (let i = 0; i < 140; i++) {
    const y = rand() * H;
    const a = rand() * 0.05;
    g.beginPath();
    for (let x = 0; x <= W; x += 32) g.lineTo(x, y + Math.sin((x / W) * TAU * 2 + y) * 3);
    outline(g, `rgba(150, 90, 50, ${a})`, 1 + rand() * 2);
  }
  // a faint painted creeper, kept quiet so words can sit on it
  g.beginPath();
  for (let x = 0; x <= W; x += 4) g.lineTo(x, 160 + Math.sin((x / W) * TAU * 4) * 26);
  outline(g, 'rgba(208, 138, 36, 0.16)', 3);
  for (let i = 0; i < 16; i++) {
    const x = (i + 0.25) * (W / 16);
    const y = 160 + Math.sin((x / W) * TAU * 4) * 26;
    wrapped(g, W, 0, x, y, () => {
      g.rotate(i % 2 ? 0.7 : -0.7);
      g.beginPath();
      g.ellipse(0, i % 2 ? 12 : -12, 6, 13, 0, 0, TAU);
      fill(g, 'rgba(208, 138, 36, 0.14)');
    });
  }
  g.fillStyle = P.gold;
  g.fillRect(0, 0, W, 9);
  g.fillStyle = P.goldLight;
  g.fillRect(0, 2, W, 2);
  g.fillStyle = P.ink;
  g.fillRect(0, 9, W, 4);
  g.fillStyle = '#3a0a0d';
  g.fillRect(0, 13, W, 50);
  for (let i = 0; i < 32; i++) {
    const x = i * 32;
    g.beginPath();
    g.moveTo(x + 2, 60);
    g.lineTo(x + 16, 18);
    g.lineTo(x + 30, 60);
    g.closePath();
    fill(g, i % 2 ? P.gold : P.madhuRed);
    outline(g, P.goldDeep, 2);
  }
  g.fillStyle = P.gold;
  g.fillRect(0, 63, W, 6);
  g.fillStyle = 'rgba(0, 0, 0, 0.35)';
  g.fillRect(0, 69, W, 6);
  return canvas;
}

/**
 * One unit of the toran under the top board: maroon cloth with a scalloped
 * hem trimmed in zari, a bandhanwar of mango leaves along the top, a marigold
 * swag with drops at the unit's edges, and a brass bell under each scallop.
 */
function paintValance(rand: Rand): HTMLCanvasElement {
  const W = 768;
  const H = 512;
  const [canvas, g] = surface(W, H);
  const tuck = (C.valance.tuck / C.valance.height) * H;
  const lobe = W / 2;
  const edge = (x: number) => {
    const u = (((x % lobe) + lobe) % lobe) / lobe - 0.5;
    return 236 + 74 * Math.sqrt(Math.max(0, 1 - 4 * u * u));
  };
  const hemPath = (inset: number) => {
    g.beginPath();
    g.moveTo(-4, 0);
    g.lineTo(W + 4, 0);
    for (let x = W + 4; x >= -4; x -= 2) g.lineTo(x, edge(x) - inset);
    g.closePath();
  };

  hemPath(0);
  fill(g, P.maroon);
  g.save();
  hemPath(0);
  g.clip();
  // block-printed rows: cream dots, small gold paisleys, a row of mirrors
  for (let x = 8; x < W; x += 16) {
    g.beginPath();
    g.arc(x, tuck + 34, 3, 0, TAU);
    fill(g, P.cream);
  }
  for (let i = 0; i < 12; i++) {
    g.save();
    g.translate(i * 64 + 32, tuck + 92);
    g.rotate(i % 2 ? 0.35 : -0.35);
    g.scale(i % 2 ? -22 : 22, 22);
    butaPath(g);
    fill(g, P.turmeric);
    outline(g, P.ink, 0.09);
    g.restore();
  }
  for (let i = 0; i < 8; i++) {
    const x = i * 96 + 48;
    g.beginPath();
    g.arc(x, tuck + 146, 9, 0, TAU);
    fill(g, P.silver);
    outline(g, P.gold, 4);
    g.beginPath();
    g.arc(x - 3, tuck + 143, 3, 0, TAU);
    fill(g, '#ffffff');
  }
  g.restore();
  g.fillStyle = P.gold;
  g.fillRect(0, tuck, W, 10);
  g.fillStyle = P.goldDeep;
  g.fillRect(0, tuck + 10, W, 2);
  // the zari trim and marigold piping following the scallops
  hemPath(9);
  outline(g, P.gold, 13);
  hemPath(18);
  outline(g, P.saffron, 4);
  hemPath(0);
  outline(g, '#3b070b', 3);
  // bead fringe
  for (let x = 6; x < W; x += 12) {
    const y = edge(x);
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x, y + 7);
    outline(g, P.goldDeep, 1.5);
    g.beginPath();
    g.arc(x, y + 10, 3.5, 0, TAU);
    fill(g, (x / 12) % 2 < 1 ? P.gold : P.madhuRed);
  }
  // a brass bell under each scallop
  for (let i = 0; i < 2; i++) {
    g.save();
    g.translate((i + 0.5) * lobe, edge((i + 0.5) * lobe) + 2);
    bell(g, 34, 56);
    g.restore();
  }

  // bandhanwar: mango leaves along a cord, a small marigold between each pair
  const cordY = tuck + 6;
  for (let i = 0; i < 16; i++) {
    wrapped(g, W, 0, i * 48 + 24, cordY, () => {
      g.rotate((i % 2 ? 1 : -1) * 0.1 + (rand() - 0.5) * 0.08);
      mangoLeaf(g, 78 + rand() * 10, 15);
    });
  }
  g.beginPath();
  g.moveTo(0, cordY);
  g.lineTo(W, cordY);
  outline(g, '#6b3b12', 4);
  for (let i = 0; i < 8; i++) marigold(g, i * 96 + 48, cordY + 4, 12, rand, i % 2 === 0);

  // the marigold swag across the unit, with drops at its edges
  const top = tuck + 14;
  const sag = 150;
  const swagY = (x: number) => top + sag * (1 - ((x - W / 2) / (W / 2)) ** 2);
  const flowers: [number, number][] = [];
  let run = 0;
  for (let x = 0, py = swagY(0); x <= W; x += 1) {
    const y = swagY(x);
    run += Math.hypot(1, y - py);
    if (run >= 25) {
      run = 0;
      flowers.push([x, y]);
    }
  }
  flowers.forEach(([x, y], i) => marigold(g, x, y, 21, rand, i % 5 >= 3));
  for (const x of [0, W]) {
    for (let k = 0; k < 10; k++) marigold(g, x, top + 26 + k * 24, 17, rand, k % 3 === 2);
    g.save();
    g.translate(x, top + 26 + 10 * 24 - 8);
    mangoLeaf(g, 44, 11);
    g.restore();
    marigold(g, x, top, 26, rand, true);
    marigold(g, x, top, 15, rand, false);
  }
  return canvas;
}

/** The painted board with the title, hanging on two cords. */
function paintTitle(canvas: HTMLCanvasElement): void {
  const g = canvas.getContext('2d')!;
  const W = canvas.width;
  const H = canvas.height;
  g.clearRect(0, 0, W, H);
  g.lineCap = 'round';
  g.lineJoin = 'round';
  for (const x of [330, W - 330]) {
    g.beginPath();
    g.moveTo(x, 0);
    g.lineTo(x, 48);
    outline(g, P.goldDeep, 9);
    g.setLineDash([5, 9]);
    outline(g, P.goldLight, 5);
    g.setLineDash([]);
  }
  const board = (k: number) => {
    g.save();
    g.translate(W / 2, 198);
    g.scale(k, k * 1.04 - 0.04);
    g.translate(-W / 2, -198);
    g.beginPath();
    g.moveTo(150, 38);
    g.lineTo(W - 150, 38);
    g.bezierCurveTo(W - 92, 38, W - 80, 122, W - 34, 198);
    g.bezierCurveTo(W - 80, 274, W - 92, 358, W - 150, 358);
    g.lineTo(150, 358);
    g.bezierCurveTo(92, 358, 80, 274, 34, 198);
    g.bezierCurveTo(80, 122, 92, 38, 150, 38);
    g.closePath();
    g.restore();
  };
  g.save();
  g.shadowColor = 'rgba(0, 0, 0, 0.55)';
  g.shadowBlur = 14;
  g.shadowOffsetY = 6;
  board(1);
  fill(g, '#45080d');
  g.restore();
  board(1);
  outline(g, P.goldDeep, 10);
  board(0.975);
  outline(g, P.goldLight, 3);
  board(0.92);
  const panel = g.createRadialGradient(W / 2, 190, 40, W / 2, 198, 620);
  panel.addColorStop(0, '#a3221a');
  panel.addColorStop(1, '#5a0c12');
  fill(g, panel);
  board(0.92);
  outline(g, P.gold, 4);
  board(0.88);
  g.setLineDash([0.5, 13]);
  outline(g, P.goldLight, 6);
  g.setLineDash([]);
  // gold kangura along the top and bottom of the panel
  for (let x = 230; x <= W - 230; x += 26) {
    for (const [y, d] of [[66, 1], [330, -1]] as const) {
      g.beginPath();
      g.moveTo(x - 9, y);
      g.lineTo(x, y + d * 13);
      g.lineTo(x + 9, y);
      g.closePath();
      fill(g, P.gold);
    }
  }
  // a little sun and a little moon at either end
  g.save();
  g.translate(210, 198);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    g.beginPath();
    g.moveTo(Math.cos(a - 0.17) * 26, Math.sin(a - 0.17) * 26);
    g.lineTo(Math.cos(a) * 46, Math.sin(a) * 46);
    g.lineTo(Math.cos(a + 0.17) * 26, Math.sin(a + 0.17) * 26);
    g.closePath();
    fill(g, i % 2 ? P.gold : P.goldLight);
  }
  g.beginPath();
  g.arc(0, 0, 25, 0, TAU);
  fill(g, P.goldLight);
  g.beginPath();
  g.arc(0, 0, 15, 0, TAU);
  fill(g, P.rose);
  g.restore();
  g.save();
  g.translate(W - 205, 198);
  g.rotate(Math.PI + 0.35);
  crescentPath(g, 40, 0.5);
  fill(g, P.goldLight);
  crescentPath(g, 31, 0.62);
  outline(g, P.blue, 4);
  g.restore();

  g.font = TITLE_FONT;
  g.textAlign = 'center';
  g.textBaseline = 'alphabetic';
  const text = C.title.text;
  const width = g.measureText(text).width;
  const scale = Math.min(1, 640 / width);
  g.save();
  g.translate(W / 2, 244);
  g.scale(scale, scale);
  g.shadowColor = 'rgba(20, 0, 0, 0.7)';
  g.shadowBlur = 6;
  g.shadowOffsetY = 4;
  const ink = g.createLinearGradient(0, -110, 0, 10);
  ink.addColorStop(0, P.goldLight);
  ink.addColorStop(0.55, '#e9b955');
  ink.addColorStop(1, P.gold);
  g.fillStyle = ink;
  g.fillText(text, 0, 0);
  g.restore();
}

function texture(canvas: HTMLCanvasElement, wrapS: THREE.Wrapping, wrapT: THREE.Wrapping): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(canvas);
  t.colorSpace = THREE.SRGBColorSpace;
  t.premultiplyAlpha = true;
  t.flipY = false;
  t.wrapS = wrapS;
  t.wrapT = wrapT;
  t.anisotropy = 8;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.generateMipmaps = true;
  return t;
}

/** Every painted canvas of the theatre (exported so they can be looked at on their own). */
export function paintTheatre() {
  const rand = seededRandom(C.seed);
  const [title] = surface(1280, 384);
  paintTitle(title);
  return {
    print: paintPrint(rand),
    zari: paintZari(),
    frame: paintFrame(rand),
    corner: paintCorner(),
    apron: paintApron(rand),
    valance: paintValance(rand),
    title,
  };
}
// #endregion

const FRAGMENT = /* glsl */ `
${GLSL_COMMON}
#define TAU 6.28318530718
uniform vec2 uResolution;
uniform float uPxPerUnit;
uniform float uZoom;
uniform float uTime;
uniform vec4 uFrame;     // pillar width, top board height, apron height, floor depth
uniform vec4 uFrameAt;   // pillar inner x, top board bottom y, apron top y, top board top y
uniform vec2 uRepeat;    // frame band repeat, apron repeat
uniform vec4 uValance;   // top y, height, unit width, its bottom (for shadows)
uniform vec4 uTitle;     // top y, width, height
uniform vec4 uDrapeX;    // outer x, leading edge x at the top, extra at the hem, cloth width (left drape)
uniform vec4 uDrapeY;    // top y, hem y, tassel length, tassel spacing
uniform vec4 uFold;      // wavelength, steepness per bunching, breathe phase, breathe amount
uniform vec4 uPrint;     // print repeat, border width, border repeat, hem border width
uniform vec3 uMirror;    // radius, glint, tassel swing
uniform vec3 uLightDir;
uniform vec3 uGlintDir;
uniform vec4 uPool;      // lamp pool centre, radii
uniform vec4 uLamp;      // light, ambient, flicker, calm darkening
uniform vec4 uCalm;      // calm centre, radii
uniform vec2 uCalmPrint; // print softening, zari dimming
uniform vec2 uShadow;    // amount, reach
uniform vec3 uGround;
uniform vec3 uShadowTint;
uniform vec3 uSilver;
uniform vec3 uFloor;
uniform vec3 uGold;
uniform vec3 uTassel[6];
uniform sampler2D tPrint;
uniform sampler2D tZari;
uniform sampler2D tFrame;
uniform sampler2D tCorner;
uniform sampler2D tApron;
uniform sampler2D tValance;
uniform sampler2D tTitle;

vec4 under(vec4 front, vec4 back) { return front + (1.0 - front.a) * back; }
float cov(float sd, float px) { return clamp(0.5 - sd / px, 0.0, 1.0); }

float vnoise(float x) {
  float i = floor(x);
  float f = fract(x);
  return mix(hash12(vec2(i, 3.7)), hash12(vec2(i + 1.0, 3.7)), f * f * (3.0 - 2.0 * f)) - 0.5;
}
float vnoise2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash12(i), hash12(i + vec2(1.0, 0.0)), f.x), mix(hash12(i + vec2(0.0, 1.0)), hash12(i + vec2(1.0)), f.x), f.y);
}

float calmAt(vec2 q) {
  vec2 d = (q - uCalm.xy) / uCalm.zw;
  return exp(-dot(d, d));
}

vec4 titleBoard(vec2 q) {
  vec2 uv = vec2(q.x / uTitle.y + 0.5, (uTitle.x - q.y) / uTitle.z);
  vec2 inside = step(vec2(0.0), uv) * step(uv, vec2(1.0));
  return texture(tTitle, uv) * inside.x * inside.y;
}

// The painted proscenium: pillars, top board, corner blocks and the apron.
vec4 frame(vec2 q, float px) {
  float ax = abs(q.x);
  float w = uFrame.x;
  vec4 pillar = texture(tFrame, vec2(q.y / uRepeat.x, (uFrameAt.x + w - ax) / w));
  vec4 board = texture(tFrame, vec2(q.x / uRepeat.x, (uFrameAt.w - q.y) / uFrame.y));
  vec4 cornerTop = texture(tCorner, vec2((ax - uFrameAt.x) / w, (uFrameAt.w - q.y) / uFrame.y));
  vec4 cornerFoot = texture(tCorner, vec2((ax - uFrameAt.x) / w, (uFrameAt.z - q.y) / uFrame.z));
  vec4 apron = texture(tApron, vec2(q.x / uRepeat.y, (uFrameAt.z - q.y) / uFrame.z));
  float inP = clamp((ax - uFrameAt.x) / px + 0.5, 0.0, 1.0);
  float inT = clamp((q.y - uFrameAt.y) / px + 0.5, 0.0, 1.0);
  float inA = clamp((uFrameAt.z - q.y) / px + 0.5, 0.0, 1.0);
  vec4 c = cornerTop * inP * inT + cornerFoot * inP * inA + pillar * inP * (1.0 - inT) * (1.0 - inA)
         + board * inT * (1.0 - inP) + apron * inA * (1.0 - inP);
  // painted wood: the edges round off into shadow
  float across = mix(mix((uFrameAt.x + w - ax) / w, (uFrameAt.w - q.y) / uFrame.y, inT * (1.0 - inP)), 0.5, inA);
  c.rgb *= 1.0 - 0.25 * smoothstep(0.82, 1.0, across) - 0.12 * smoothstep(0.12, 0.0, across);
  return c;
}

// Soft shadows the frame casts on whatever hangs behind it.
float frameShadow(vec2 q) {
  float side = max(uFrameAt.x - abs(q.x), 0.0);
  float top = max(uFrameAt.y - q.y, 0.0);
  return (1.0 - 0.5 * exp(-side / 0.028)) * (1.0 - 0.55 * exp(-top / 0.022));
}

vec4 valance(vec2 q) {
  vec2 uv = vec2(q.x / uValance.z + 0.5, (uValance.x - q.y) / uValance.y);
  vec4 c = texture(tValance, uv) * step(uv.y, 1.0);
  // the title board's shadow
  vec2 b = vec2(abs(q.x) - 0.5 * uTitle.y + 0.01, uTitle.x - uTitle.z - q.y + 0.012);
  float board = smoothstep(0.03, -0.01, max(b.x, -b.y)) * step(uTitle.x - uTitle.z - 0.05, q.y);
  c.rgb *= frameShadow(q) * (1.0 - 0.45 * board);
  return c;
}

// One latkan: a gold cord, a bead, a cap and a flared thread skirt. d: across, and down
// from the hem; lit from the left of the screen (side flips the drape's mirrored frame).
vec4 tassel(vec2 d, float len, float pick, float side, float px) {
  float cordL = 0.2 * len;
  float beadR = 0.075 * len;
  float y1 = cordL + 2.0 * beadR;
  float y2 = y1 + 0.08 * len;
  float y3 = len;
  float cord = cov(max(abs(d.x) - 0.02 * len, max(-d.y, d.y - cordL)), px);
  float bead = cov(length(d - vec2(0.0, cordL + beadR)) - beadR, px);
  float cap = cov(max(abs(d.x) - mix(0.04, 0.075, clamp((d.y - y1) / (y2 - y1), 0.0, 1.0)) * len, max(y1 - d.y, d.y - y2)), px);
  float t = clamp((d.y - y2) / (y3 - y2), 0.0, 1.0);
  float half_ = mix(0.065, 0.125, sqrt(t)) * len;
  float skirt = cov(max(abs(d.x) - half_, max(y2 - d.y, d.y - y3 + 0.03 * len * (d.x * d.x) / (half_ * half_))), px);
  int k = int(floor(pick * 2.999));
  float lx = -d.x * side;
  float round_ = 0.78 + 0.32 * clamp(lx / half_, -1.0, 1.0);
  vec3 sk = uTassel[k * 2] * round_ * (0.78 + 0.22 * cos(d.x / half_ * 12.0)) * mix(1.0, 0.7, t * t);
  vec3 c = uGold * (0.8 + 0.3 * clamp(lx / (0.075 * len), -1.0, 1.0));
  float a = max(cord, cap);
  vec2 hl = d - vec2(-0.35 * beadR * side, cordL + 0.6 * beadR);
  c = mix(c, uTassel[k * 2 + 1] * (0.8 + 0.7 * smoothstep(0.6 * beadR, 0.0, length(hl))), bead);
  a = max(a, bead);
  c = mix(c, sk, skirt * (1.0 - bead));
  a = max(a, skirt);
  return vec4(c * a, a);
}

// The tassels of one drape (side 1 left, -1 right) nearest this pixel along its hem.
vec4 tassels(vec2 q, float side, float yHem, float px) {
  float x = q.x * side;
  float xiH = uDrapeX.y + uDrapeX.z;
  float spanH = max(xiH - uDrapeX.x, 1e-3);
  float cloth = uDrapeX.w;
  float sH = (xiH - x) / spanH * cloth;
  float seed = side * 23.0;
  vec4 tas = vec4(0.0);
  for (int j = -1; j <= 1; j++) {
    float kk = floor(sH / uDrapeY.w) + float(j);
    float sk = (kk + 0.5) * uDrapeY.w;
    vec2 d = vec2(x - (xiH - sk / cloth * spanH), yHem - q.y);
    d.x -= d.y * uMirror.z * (0.7 + 0.6 * hash12(vec2(kk, seed + 1.0)));
    vec4 one = tassel(d, uDrapeY.z, hash12(vec2(kk, seed + 2.0)), side, px) * step(0.0, sk) * step(sk, cloth);
    tas = one.a > tas.a ? one : tas;
  }
  return tas;
}

vec4 drapes(vec2 q, float px) {
  float yTop = uDrapeY.x;
  float yHem = uDrapeY.y;
  float h = clamp((yTop - q.y) / (yTop - yHem), 0.0, 1.0);
  float xi = uDrapeX.y + uDrapeX.z * h * h;
  // Work in the left drape's frame; the right drape is its mirror image.
  float side = q.x <= xi ? 1.0 : -1.0;
  float x = q.x * side;
  float xo = uDrapeX.x;
  float span = max(xi - xo, 1e-3);
  float cloth = uDrapeX.w;
  float bunch = cloth / span;
  float sLin = (xi - x) / span * cloth;
  float seed = side * 23.0;

  // Folds: small folds riding on a few broad ones, unevenly spaced, fanning a
  // little toward the hem; steeper the tighter the cloth is gathered.
  float u = sLin / uFold.x;
  float ph = TAU * (u + 0.55 * vnoise(u * 0.41 + seed) + h * 0.4 * vnoise(u * 0.27 + seed + 9.0)
                  + uFold.w * sin(TAU * uFold.z + u * 1.7));
  float ph2 = TAU * (u * 0.36 + 0.4 * vnoise(u * 0.19 + seed + 4.0) + h * 0.25 * vnoise(u * 0.13 + seed + 2.0));
  float z = 0.7 * sin(ph) + 0.3 * sin(ph2);
  float steep = uFold.y * sqrt(max(bunch * bunch - 1.0, 0.0)) + 0.3;
  float slope = side * steep * (cos(ph) + 0.55 * cos(ph2));

  // Ridges hang a touch lower than the valleys behind them.
  float hemY = yHem - 0.004 * z * clamp(bunch - 1.0, 0.0, 1.0);
  float above = q.y - hemY;
  float cover = clamp((xi - x) / px + 0.5, 0.0, 1.0) * clamp(above / px + 0.5, 0.0, 1.0) * step(xo, x);

  // The flat cloth's coordinates: the print bunches on the steep sides of each fold.
  float s = sLin + uFold.x / (2.0 * TAU) * 0.65 * (1.0 - 1.0 / bunch) * sin(2.0 * ph);
  vec2 st = vec2(s, yTop - q.y);
  float calm = calmAt(q);

  vec2 tile = st / uPrint.x + vec2(0.37 * side, 0.0);
  vec4 pr = texture(tPrint, tile) * clamp(0.8 + 0.4 * vnoise2(st * 24.0 + seed), 0.0, 1.0) * (1.0 - uCalmPrint.x * calm);
  vec3 c = uGround * (1.0 - pr.a) + pr.rgb;
  // The zari border down the leading edge, and the same border, scaled down, along the hem.
  float kH = uPrint.w / uPrint.y;
  vec4 zi = texture(tZari, vec2(s / uPrint.y, st.y / uPrint.z)) * step(s, uPrint.y);
  vec4 zh = texture(tZari, vec2(above / uPrint.w, s / (uPrint.z * kH))) * step(above, uPrint.w);
  c = zi.rgb + (1.0 - zi.a) * c;
  c = zh.rgb + (1.0 - zh.a) * c;
  c *= 1.0 - uCalmPrint.y * calm * max(zi.a, zh.a);
  float metal = max(zi.a, zh.a) * clamp((c.g - c.b) * 3.0, 0.0, 1.0);

  // Shisha mirrors: at the print's flower hearts, and down both zari borders.
  vec2 f = fract(tile);
  vec2 d1 = f - vec2(0.75, 0.30);
  d1 -= floor(d1 + 0.5);
  vec2 d2 = f - vec2(0.25, 0.80);
  d2 -= floor(d2 + 0.5);
  vec2 dm = dot(d1, d1) < dot(d2, d2) ? d1 : d2;
  float rm = length(dm * uPrint.x) / uMirror.x + (1.0 - (1.0 - zi.a) * (1.0 - zh.a)) * 9.0;
  vec2 id = floor(tile - dm + 0.5) * vec2(2.0, 1.0) + side;
  float along = uPrint.z * 0.5;
  vec2 db = vec2(s - 0.336 * uPrint.y, (fract(st.y / along) - 0.5) * along);
  float rb = length(db) / (uMirror.x * 0.95) + step(uPrint.y, s) * 9.0 + zh.a * 9.0;
  id = rb < rm ? vec2(floor(st.y / along), 17.0 + side) : id;
  rm = min(rm, rb);
  vec2 dh = vec2((fract(s / (along * kH)) - 0.5) * along * kH, above - 0.336 * uPrint.w);
  float rh = length(dh) / (uMirror.x * 0.95 * kH) + step(uPrint.w, above) * 9.0;
  id = rh < rm ? vec2(floor(s / (along * kH)), 31.0 + side) : id;
  rm = min(rm, rh);
  float glass = (1.0 - smoothstep(1.0 - fwidth(rm), 1.0, rm)) * (1.0 - 0.8 * calm);

  // Cloth texture: a coarse hand-loomed weave and slubs in the weft.
  float k = TAU / 0.0055;
  vec2 th = sin(st * k);
  float fine = clamp(1.6 - max(fwidth(st.x), fwidth(st.y)) * k * 0.6, 0.0, 1.0);
  c *= (1.0 + 0.09 * th.x * th.y * fine) * (0.93 + 0.14 * vnoise2(vec2(s * 9.0, st.y * 160.0) + seed));

  // Light on the folds, painted in a few soft-edged flat tones.
  vec3 n = normalize(vec3(-slope, 0.0, 1.0));
  float deep = clamp((bunch - 1.0) * 0.3, 0.2, 0.85);
  float ao = 1.0 - deep * (0.5 - 0.5 * z) * 0.8;
  float lum = max(dot(n, uLightDir), 0.0) * ao;
  float lb = (floor(lum * 4.0) + smoothstep(0.3, 0.7, fract(lum * 4.0))) / 4.0;
  float shade = mix(0.16, 1.18, lb);
  c *= shade * mix(uShadowTint, vec3(1.0), smoothstep(0.25, 0.85, shade));
  // the deepest creases read as an ink line once the cloth is bunched
  c *= 1.0 - 0.55 * smoothstep(0.93, 0.995, -sin(ph)) * clamp(bunch - 1.3, 0.0, 1.0);
  // zari catches the light along each fold
  c += metal * pow(max(dot(n, normalize(uLightDir + vec3(0.0, 0.0, 1.0))), 0.0), 14.0) * vec3(0.55, 0.42, 0.2);

  // Each mirror is sewn on a little askew, so they glint one by one as the cloth moves.
  vec2 tilt = (hash22(id) - 0.5) * 1.1;
  vec3 nm = normalize(vec3(-slope + tilt.x, tilt.y, 1.0));
  float spec = pow(max(dot(reflect(vec3(0.0, 0.0, -1.0), nm), uGlintDir), 0.0), 36.0);
  vec3 mirrorC = (uSilver * (0.32 + 0.4 * hash12(id + 5.0)) + uGround * 0.25) * mix(ao, 1.0, 0.5) + spec * uMirror.y;
  c = mix(c, mirrorC, glass);

  // shadows: under the valance and the pillars, and the left drape's on the right where they overlap
  float shadow = frameShadow(q) * (1.0 - 0.6 * smoothstep(uValance.w - 0.1, uValance.w + 0.02, q.y));
  shadow *= side < 0.0 ? 1.0 - 0.5 * exp(-max(q.x - xi, 0.0) / 0.012) : 1.0;
  c *= shadow;

  vec4 tas = vec4(0.0);
  if (q.y < yHem + 0.01 && q.y > yHem - uDrapeY.z - 0.01) {
    tas = under(tassels(q, 1.0, yHem, px), tassels(q, -1.0, yHem, px));
    tas.rgb *= frameShadow(q);
  }
  return under(vec4(c * cover, cover), tas);
}

// The stage floor between the apron and the drapes, planks running back.
vec4 stageFloor(vec2 q, float px) {
  float w = (q.y - uFrameAt.z) / uFrame.w;
  float a = clamp((q.y - uFrameAt.z) / px + 0.5, 0.0, 1.0) * (1.0 - smoothstep(0.5, 1.0, w));
  float xf = q.x / (1.0 - 0.5 * clamp(w, 0.0, 1.0));
  float seam = smoothstep(0.9, 0.98, abs(fract(xf / 0.09) - 0.5) * 2.0);
  vec3 c = uFloor * (0.85 + 0.3 * vnoise2(vec2(xf * 60.0, w * 2.0))) * (1.0 - 0.55 * seam) * mix(1.0, 0.4, w);
  // darker under the drapes
  float xi = uDrapeX.y + uDrapeX.z;
  c *= 1.0 - 0.45 * smoothstep(0.02, -0.02, min(-xi - q.x, q.x - xi) * sign(-xi));
  return vec4(c * a, a);
}

// The theatre's shadow on the story behind it, once the drapes part.
float sceneShadow(vec2 q) {
  float h = clamp((uDrapeY.x - q.y) / (uDrapeY.x - uDrapeY.y), 0.0, 1.0);
  float xi = uDrapeX.y + uDrapeX.z * h * h;
  float edge = max(min(q.x - xi, -xi - q.x), 0.0);
  float below = max(uValance.w - q.y, 0.0);
  float a = 1.0 - (1.0 - exp(-edge / uShadow.y)) * (1.0 - 0.7 * exp(-below / uShadow.y));
  return uShadow.x * a;
}

float lamp(vec2 q) {
  vec2 d = (q - uPool.xy) / uPool.zw;
  return uLamp.x * (uLamp.y + (1.0 - uLamp.y) * exp(-dot(d, d))) * (1.0 + uLamp.z) * (1.0 - uLamp.w * calmAt(q));
}

void main() {
  float px = 1.0 / (uPxPerUnit * uZoom);
  vec2 q = (gl_FragCoord.xy - 0.5 * uResolution) * px;
  vec4 c = titleBoard(q);
  c = under(c, frame(q, px));
  c = under(c, valance(q));
  c = under(c, drapes(q, px));
  c = under(c, stageFloor(q, px));
  c.rgb *= lamp(q);
  c = under(c, vec4(0.0, 0.0, 0.0, sceneShadow(q)));
  gl_FragColor = c;
}`;

const color = (hex: string) => new THREE.Color(hex);

export class Curtains {
  readonly mesh: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
  private readonly textures: THREE.Texture[];
  private readonly u: Record<string, THREE.IUniform>;

  constructor() {
    const art = paintTheatre();
    const R = THREE.RepeatWrapping;
    const E = THREE.ClampToEdgeWrapping;
    const tex = {
      tPrint: texture(art.print, R, R),
      tZari: texture(art.zari, E, R),
      tFrame: texture(art.frame, R, E),
      tCorner: texture(art.corner, E, E),
      tApron: texture(art.apron, R, E),
      tValance: texture(art.valance, R, E),
      tTitle: texture(art.title, E, E),
    };
    this.textures = Object.values(tex);
    // The title waits for its typeface; the board is repainted once it arrives.
    if (!document.fonts.check(TITLE_FONT))
      void document.fonts.load(TITLE_FONT).then(() => {
        paintTitle(art.title);
        tex.tTitle.needsUpdate = true;
      });

    const D = C.drape;
    const v2 = () => ({ value: new THREE.Vector2() });
    const v3 = () => ({ value: new THREE.Vector3() });
    const v4 = () => ({ value: new THREE.Vector4() });
    this.u = {
      ...Object.fromEntries(Object.entries(tex).map(([k, t]) => [k, { value: t }])),
      uResolution: v2(),
      uPxPerUnit: { value: 1 },
      uZoom: { value: 1 },
      uTime: { value: 0 },
      uFrame: { value: new THREE.Vector4(C.frame.pillar, C.frame.top, C.frame.apron, C.frame.floor) },
      uFrameAt: v4(),
      uRepeat: { value: new THREE.Vector2(C.frame.bandRepeat, C.frame.apronRepeat) },
      uValance: v4(),
      uTitle: v4(),
      uDrapeX: v4(),
      uDrapeY: v4(),
      uFold: { value: new THREE.Vector4(D.foldWave, D.foldSlope, 0, 0) },
      uPrint: { value: new THREE.Vector4(D.print, D.border, D.borderRepeat, D.hemBorder) },
      uMirror: { value: new THREE.Vector3(D.mirror, D.glint, 0) },
      uLightDir: { value: new THREE.Vector3(...C.lamp.direction).normalize() },
      uGlintDir: v3(),
      uPool: v4(),
      uLamp: v4(),
      uCalm: v4(),
      uCalmPrint: { value: new THREE.Vector2(C.calm.print, C.calm.zari) },
      uShadow: { value: new THREE.Vector2(C.shadow.amount, C.shadow.reach) },
      uGround: { value: color(P.vermilion) },
      uShadowTint: { value: new THREE.Vector3(...P.shadowTint) },
      uSilver: { value: color(P.silver) },
      uFloor: { value: color(P.floor) },
      uGold: { value: color(P.gold) },
      uTassel: { value: [P.marigold, P.leaf, '#b5174e', P.turmeric, P.turmeric, P.vermilion].map(color) },
    };
    this.mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(2, 2),
      new THREE.ShaderMaterial({
        vertexShader: FULLSCREEN_VERTEX,
        fragmentShader: FRAGMENT,
        uniforms: this.u,
        transparent: true,
        premultipliedAlpha: true,
        depthTest: false,
        depthWrite: false,
      }),
    );
    this.mesh.renderOrder = 20;
    this.mesh.frustumCulled = false;
  }

  update(state: StoryState, view: View): void {
    const { open, light } = state.curtain;
    this.mesh.visible = open < 1;
    if (!this.mesh.visible) return;
    const u = this.u;
    const D = C.drape;
    const F = C.frame;
    const M = C.motion;
    const t = state.t;
    const hw = view.worldWidth / 2;
    const hh = view.worldHeight / 2;

    // The drapes part; the theatre then clears: a push in while every piece
    // withdraws past the screen's edge (by enough to be gone at the end).
    // The drapes ease out of the opening's own ease, so they part from the first moment.
    const part = Math.sin((progress(open, M.part) * Math.PI) / 2);
    const clear = ramp(open, M.clear);
    const zoom = 1 + M.push * clear;
    const outW = hw / (1 + M.push) + M.margin;
    const outH = hh / (1 + M.push) + M.margin;
    const go = clear * M.exit;

    const boardBottom = hh - F.top;
    const valanceTop = boardBottom + C.valance.tuck;
    const titleTop = boardBottom + C.title.tuck;
    const hang = Math.min(valanceTop - C.valance.height, titleTop - C.title.height);
    const fly = Math.max(0, outH - hang) * go;
    const pillarIn = hw - F.pillar;
    const sideways = Math.max(0, outW - pillarIn) * go;
    const apronTop = -hh + F.apron;
    const sink = Math.max(0, apronTop + F.floor + outH) * go;

    const outer = -(hw - F.pillar * 0.5);
    const cloth = D.fullness * (D.overlap - outer);
    const gathered = outer + cloth / D.gather;
    const withdraw = Math.max(0, gathered + outW) * go;
    const leading = lerp(D.overlap, gathered, part) - withdraw;
    // The hem trails the moving drape, swings once a little past, and settles.
    const opening = t < TIMELINE.touchAt;
    const p = opening ? part : 1 - part;
    const trail = state.reducedMotion ? 0 : Math.sin(Math.PI * p) * (1 - D.settle * p * p) * (opening ? 1 : -1);

    u.uResolution.value.set(view.pxWidth, view.pxHeight);
    u.uPxPerUnit.value = view.pxPerWorld;
    u.uZoom.value = zoom;
    u.uTime.value = t;
    u.uFrameAt.value.set(pillarIn + sideways, boardBottom + fly, apronTop - sink, hh + fly);
    u.uValance.value.set(valanceTop + fly, C.valance.height, C.valance.unit, valanceTop - C.valance.height * 0.62 + fly);
    u.uTitle.value.set(titleTop + fly, C.title.width, C.title.height, 0);
    u.uDrapeX.value.set(outer - withdraw, leading, D.lag * trail, cloth);
    u.uDrapeY.value.set(boardBottom, apronTop + D.hemGap - sink, D.tassel.length, D.tassel.spacing);
    u.uFold.value.z = (D.breathe.hz * t) % 1;
    u.uFold.value.w = state.reducedMotion ? 0 : D.breathe.amount;
    u.uMirror.value.z = D.tasselSwing * trail;

    const L = C.lamp;
    const grow = lerp(L.grow, 1, easeOutCubic(light));
    const flicker = state.reducedMotion ? 0 : L.flicker * (0.6 * Math.sin(t * 7.3) + 0.4 * Math.sin(t * 12.9 + 1.3));
    u.uPool.value.set(L.at[0] * hw, L.at[1] * hh, L.radius[0] * hw * grow, L.radius[1] * hh * grow);
    u.uLamp.value.set(light, L.ambient, flicker, C.calm.light);
    u.uGlintDir.value.set(L.glint[0] + L.glintSway * Math.sin(t * 0.9), L.glint[1], 1).normalize();

    // Where "Press Enter to restart" sits on the closed curtains (see CURTAINS.calm).
    const K = C.calm;
    const rem = 16;
    const font = clamp(K.fontRem[1] * rem + (K.fontRem[2] / 100) * view.cssWidth, K.fontRem[0] * rem, K.fontRem[3] * rem);
    const boxH = font * 1.2 + 2 * K.padRem * rem;
    const short = Math.min(view.cssWidth, view.cssHeight);
    u.uCalm.value.set(
      0,
      -hh + (K.bottom * view.cssHeight + boxH / 2) / short,
      ((font * K.widthEm) / 2 / short) * K.spread[0],
      (boxH / 2 / short) * K.spread[1],
    );
  }

  dispose(): void {
    for (const t of this.textures) t.dispose();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
