import { PERF } from '../config.ts';

/**
 * Watches frame rate and steps the quality level down (never up, so it cannot
 * oscillate) when the average stays below PERF.lowFps for a whole window.
 */
export class QualityGovernor {
  level = 0;
  private windowStart = 0;
  private frames = 0;
  private settleUntil = 0;
  private lastMs = -Infinity;

  /** Call after start, resize, tab switch or a level change: those frames are not representative. */
  settle(nowMs: number): void {
    this.settleUntil = nowMs + PERF.settleSeconds * 1000;
    this.windowStart = this.settleUntil;
    this.frames = 0;
  }

  /** Returns true when the level changed. */
  frame(nowMs: number): boolean {
    // A long gap is a pause, a hidden tab or a lost context, not a slow GPU.
    const gap = nowMs - this.lastMs;
    this.lastMs = nowMs;
    if (gap > PERF.maxFrameGapMs) this.settle(nowMs);
    if (nowMs < this.settleUntil) return false;
    this.frames++;
    const elapsed = (nowMs - this.windowStart) / 1000;
    if (elapsed < PERF.windowSeconds) return false;
    const fps = this.frames / elapsed;
    this.windowStart = nowMs;
    this.frames = 0;
    if (fps >= PERF.lowFps || this.level >= PERF.levels.length - 1) return false;
    this.level++;
    console.info(`[quality] ${fps.toFixed(1)} fps -> level ${this.level}`, PERF.levels[this.level]);
    this.settle(nowMs);
    return true;
  }
}
