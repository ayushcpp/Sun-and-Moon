// The spoken words on screen, drawn on a 2D canvas the size of the drawing
// buffer as a pure function of the story time, uploaded as a texture and laid
// over the scene (above the eyes, below the curtains). The dialogue is drawn by
// render/dialogue.ts over the storybook; the poem by render/poem.ts over the eyes.
import * as THREE from 'three';
import { INPUT, STORY } from '../config.ts';
import { facesScale } from '../timeline.ts';
import type { InputState, StoryState, View } from '../types.ts';
import { drawDialogue } from './dialogue.ts';
import { drawPoem } from './poem.ts';
import { FULLSCREEN_VERTEX } from './shaders/common.ts';

/** What a caption drawer gets. Canvas pixels: origin top-left, y down. */
export interface CaptionFrame {
  ctx: CanvasRenderingContext2D;
  state: StoryState;
  view: View;
  /** The eyes picture on screen (canvas px): top-left corner, size, and px per picture px. */
  faces: { x: number; y: number; width: number; height: number; scale: number };
}

// The canvas is uploaded as plain RGBA8 (an sRGB texture format makes the driver
// convert every pixel on upload, ~30 ms a frame at 1080p); it is decoded here.
// Canvas pixels are premultiplied sRGB, so the colour is un-premultiplied first.
const FRAGMENT = /* glsl */ `
uniform sampler2D tMap;
vec3 srgbToLinear(vec3 c) {
  return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(0.04045, c));
}
void main() {
  vec4 c = texelFetch(tMap, ivec2(gl_FragCoord.xy), 0);
  if (c.a <= 0.0) discard;
  gl_FragColor = vec4(srgbToLinear(c.rgb / c.a) * c.a, c.a);
}`;

export class Captions {
  readonly mesh: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
  private readonly canvas = document.createElement('canvas');
  private readonly ctx = this.canvas.getContext('2d')!;
  private readonly texture = new THREE.CanvasTexture(this.canvas);

  constructor() {
    this.texture.colorSpace = THREE.NoColorSpace;
    this.texture.premultiplyAlpha = true;
    this.texture.generateMipmaps = false;
    this.texture.minFilter = THREE.NearestFilter;
    this.texture.magFilter = THREE.NearestFilter;
    this.mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(2, 2),
      new THREE.ShaderMaterial({
        vertexShader: FULLSCREEN_VERTEX,
        fragmentShader: FRAGMENT,
        uniforms: { tMap: { value: this.texture } },
        transparent: true,
        premultipliedAlpha: true,
        depthTest: false,
        depthWrite: false,
      }),
    );
    this.mesh.renderOrder = 10;
    this.mesh.frustumCulled = false;
  }

  update(state: StoryState, input: InputState, view: View): void {
    const { canvas, ctx } = this;
    if (canvas.width !== view.pxWidth || canvas.height !== view.pxHeight) {
      canvas.width = view.pxWidth;
      canvas.height = view.pxHeight;
    }
    // Same placement as render/faces.ts, so words can sit on the drawing.
    const k = facesScale(view) * state.faces.zoom * view.pxPerWorld;
    const [fw, fh] = STORY.faces.size;
    const par = INPUT.parallaxPx.faces * view.dpr;
    const cx = view.pxWidth / 2 + input.pointer.x * par;
    const cy = view.pxHeight / 2 - input.pointer.y * par;
    const frame: CaptionFrame = { ctx, state, view, faces: { x: cx - (fw * k) / 2, y: cy - (fh * k) / 2, width: fw * k, height: fh * k, scale: k } };

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const drew = drawDialogue(frame) || drawPoem(frame);
    this.mesh.visible = drew;
    if (drew) this.texture.needsUpdate = true;
  }

  dispose(): void {
    this.texture.dispose();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
