// The two voices (public/audio), played in step with the story clock through
// Web Audio. Each frame the story time is compared with where the audio is; if
// they part (pause, scrub, restart, a hidden tab) the clips are rescheduled from
// the story time, so the sound always follows the picture.
import { SOUND, TIMELINE as TL } from './config.ts';

export interface Soundtrack {
  /** Call every frame with the story time and whether it is running. */
  update(t: number, playing: boolean): void;
  /** Starts sound; browsers allow it only inside a click, tap or key press. */
  unlock(): void;
  /** True once the browser lets the page play sound. */
  readonly unlocked: boolean;
  toggleMute(): boolean;
  readonly muted: boolean;
}

type Clip = keyof typeof TL.audio;

export function createSoundtrack(onUnlocked: () => void): Soundtrack {
  const ctx = new AudioContext({ latencyHint: 'playback' });
  const master = ctx.createGain();
  master.gain.value = SOUND.volume;
  master.connect(ctx.destination);

  const buffers: Partial<Record<Clip, AudioBuffer>> = {};
  for (const clip of Object.keys(TL.audio) as Clip[]) {
    fetch(`${import.meta.env.BASE_URL}${SOUND.files[clip]}`)
      .then((r) => (r.ok ? r.arrayBuffer() : Promise.reject(new Error(`${SOUND.files[clip]}: ${r.status}`))))
      .then((data) => ctx.decodeAudioData(data))
      .then((b) => (buffers[clip] = b))
      .catch((err) => console.warn('[sound]', err));
  }

  let muted = false;
  /** What is scheduled: the story time `t0` that plays at audio time `c0`, and the nodes playing it. */
  let session: { t0: number; c0: number; out: GainNode; sources: AudioBufferSourceNode[]; clips: number } | null = null;

  const stop = () => {
    if (!session) return;
    const { out, sources } = session;
    const now = ctx.currentTime;
    out.gain.setTargetAtTime(0, now, SOUND.declick / 3);
    for (const s of sources) s.stop(now + SOUND.declick);
    session = null;
  };

  const start = (t: number) => {
    const now = ctx.currentTime;
    const out = ctx.createGain();
    out.gain.setValueAtTime(0, now);
    out.gain.setTargetAtTime(1, now, SOUND.declick / 3);
    out.connect(master);
    const sources: AudioBufferSourceNode[] = [];
    for (const clip of Object.keys(TL.audio) as Clip[]) {
      const buffer = buffers[clip];
      if (!buffer) continue;
      const offset = t - TL.audio[clip];
      if (offset >= buffer.duration) continue;
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.connect(out);
      // A clip still ahead starts later; one under way starts part-way through.
      src.start(now + Math.max(0, -offset), Math.max(0, offset));
      sources.push(src);
    }
    session = { t0: t, c0: now, out, sources, clips: Object.keys(buffers).length };
  };

  const unlocked = () => ctx.state === 'running';
  if (unlocked()) queueMicrotask(onUnlocked);
  ctx.addEventListener('statechange', () => unlocked() && onUnlocked());

  return {
    update(t, playing) {
      if (!unlocked()) return;
      if (!playing || t >= TL.end) return stop();
      // A clip that finished decoding since the last schedule joins in.
      const stale = session && session.clips !== Object.keys(buffers).length;
      const drift = session ? Math.abs(session.t0 + (ctx.currentTime - session.c0) - t) : Infinity;
      if (drift > SOUND.syncTolerance || stale) {
        stop();
        start(t);
      }
    },
    unlock() {
      if (!unlocked()) void ctx.resume();
    },
    get unlocked() {
      return unlocked();
    },
    toggleMute() {
      muted = !muted;
      master.gain.setTargetAtTime(muted ? 0 : SOUND.volume, ctx.currentTime, SOUND.muteSeconds / 3);
      return muted;
    },
    get muted() {
      return muted;
    },
  };
}
